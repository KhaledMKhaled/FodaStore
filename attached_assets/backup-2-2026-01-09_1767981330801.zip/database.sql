--
-- PostgreSQL database dump
--

-- Dumped from database version 16.11 (f45eb12)
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: _system; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _system;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: replit_database_migrations_v1; Type: TABLE; Schema: _system; Owner: -
--

CREATE TABLE _system.replit_database_migrations_v1 (
    id bigint NOT NULL,
    build_id text NOT NULL,
    deployment_id text NOT NULL,
    statement_count bigint NOT NULL,
    applied_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: replit_database_migrations_v1_id_seq; Type: SEQUENCE; Schema: _system; Owner: -
--

CREATE SEQUENCE _system.replit_database_migrations_v1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: replit_database_migrations_v1_id_seq; Type: SEQUENCE OWNED BY; Schema: _system; Owner: -
--

ALTER SEQUENCE _system.replit_database_migrations_v1_id_seq OWNED BY _system.replit_database_migrations_v1.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id character varying,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(255) NOT NULL,
    action_type character varying(50) NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    details jsonb
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_jobs (
    id integer NOT NULL,
    job_type character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    progress integer DEFAULT 0,
    output_path character varying(500),
    file_size integer,
    error text,
    manifest jsonb,
    created_by_user_id character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone
);


--
-- Name: backup_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.backup_jobs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.backup_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exchange_rates (
    id integer NOT NULL,
    rate_date date NOT NULL,
    from_currency character varying(10) NOT NULL,
    to_currency character varying(10) NOT NULL,
    rate_value numeric(15,6) NOT NULL,
    source character varying(100),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.exchange_rates ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.exchange_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inventory_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements (
    id integer NOT NULL,
    shipment_id integer,
    shipment_item_id integer,
    product_id integer,
    total_pieces_in integer DEFAULT 0,
    unit_cost_rmb numeric(10,4),
    unit_cost_egp numeric(10,4) NOT NULL,
    total_cost_egp numeric(15,2) NOT NULL,
    movement_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.inventory_movements ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inventory_movements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payment_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_allocations (
    id integer NOT NULL,
    payment_id integer NOT NULL,
    shipment_id integer NOT NULL,
    supplier_id integer NOT NULL,
    component character varying(50) NOT NULL,
    currency character varying(10) NOT NULL,
    allocated_amount numeric(15,2) NOT NULL,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: payment_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.payment_allocations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.payment_allocations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: product_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: product_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.product_types ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.product_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(100),
    default_image_url character varying,
    default_supplier_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.products ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


--
-- Name: shipment_customs_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipment_customs_details (
    id integer NOT NULL,
    shipment_id integer NOT NULL,
    total_customs_cost_egp numeric(15,2) DEFAULT '0'::numeric,
    total_takhreeg_cost_egp numeric(15,2) DEFAULT '0'::numeric,
    customs_invoice_date date,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: shipment_customs_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shipment_customs_details ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.shipment_customs_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shipment_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipment_items (
    id integer NOT NULL,
    shipment_id integer NOT NULL,
    supplier_id integer,
    product_id integer,
    product_type_id integer,
    product_name character varying(255) NOT NULL,
    description text,
    country_of_origin character varying(100) DEFAULT 'الصين'::character varying,
    image_url character varying,
    cartons_ctn integer DEFAULT 0 NOT NULL,
    pieces_per_carton_pcs integer DEFAULT 0 NOT NULL,
    total_pieces_cou integer DEFAULT 0 NOT NULL,
    purchase_price_per_piece_pri_rmb numeric(10,4) DEFAULT '0'::numeric,
    total_purchase_cost_rmb numeric(15,2) DEFAULT '0'::numeric,
    customs_cost_per_carton_egp numeric(10,2),
    total_customs_cost_egp numeric(15,2),
    takhreeg_cost_per_carton_egp numeric(10,2),
    total_takhreeg_cost_egp numeric(15,2),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    line_no integer DEFAULT 1 NOT NULL,
    missing_pieces integer DEFAULT 0 NOT NULL,
    missing_cost_egp numeric(15,2) DEFAULT '0'::numeric
);


--
-- Name: shipment_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shipment_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.shipment_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shipment_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipment_payments (
    id integer NOT NULL,
    shipment_id integer NOT NULL,
    party_type character varying(50),
    party_id integer,
    payment_date timestamp without time zone NOT NULL,
    payment_currency character varying(10) NOT NULL,
    amount_original numeric(15,2) NOT NULL,
    exchange_rate_to_egp numeric(10,4),
    amount_egp numeric(15,2) NOT NULL,
    cost_component character varying(50) NOT NULL,
    payment_method character varying(50) NOT NULL,
    cash_receiver_name character varying(255),
    reference_number character varying(100),
    note text,
    attachment_url character varying,
    attachment_mime_type character varying(255),
    attachment_size integer,
    attachment_original_name character varying(255),
    attachment_uploaded_at timestamp without time zone,
    created_by_user_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: shipment_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shipment_payments ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.shipment_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shipment_shipping_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipment_shipping_details (
    id integer NOT NULL,
    shipment_id integer NOT NULL,
    total_purchase_cost_rmb numeric(15,2) DEFAULT '0'::numeric,
    commission_rate_percent numeric(5,2) DEFAULT '0'::numeric,
    commission_value_rmb numeric(15,2) DEFAULT '0'::numeric,
    commission_value_egp numeric(15,2) DEFAULT '0'::numeric,
    shipping_area_sqm numeric(10,2) DEFAULT '0'::numeric,
    shipping_cost_per_sqm_usd_original numeric(10,2),
    total_shipping_cost_usd_original numeric(15,2),
    total_shipping_cost_rmb numeric(15,2) DEFAULT '0'::numeric,
    total_shipping_cost_egp numeric(15,2) DEFAULT '0'::numeric,
    shipping_date date,
    rmb_to_egp_rate_at_shipping numeric(10,4),
    usd_to_rmb_rate_at_shipping numeric(10,4),
    source_of_rates character varying(100),
    rates_updated_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: shipment_shipping_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shipment_shipping_details ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.shipment_shipping_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipments (
    id integer NOT NULL,
    shipment_code character varying(50) NOT NULL,
    shipment_name character varying(255) NOT NULL,
    purchase_date date NOT NULL,
    status character varying(50) DEFAULT 'جديدة'::character varying NOT NULL,
    invoice_customs_date date,
    shipping_company_id integer,
    created_by_user_id character varying,
    purchase_cost_rmb numeric(15,2) DEFAULT '0'::numeric,
    purchase_cost_egp numeric(15,2) DEFAULT '0'::numeric,
    purchase_rmb_to_egp_rate numeric(10,4) DEFAULT '0'::numeric,
    commission_cost_rmb numeric(15,2) DEFAULT '0'::numeric,
    commission_cost_egp numeric(15,2) DEFAULT '0'::numeric,
    shipping_cost_rmb numeric(15,2) DEFAULT '0'::numeric,
    shipping_cost_egp numeric(15,2) DEFAULT '0'::numeric,
    customs_cost_egp numeric(15,2) DEFAULT '0'::numeric,
    takhreeg_cost_egp numeric(15,2) DEFAULT '0'::numeric,
    final_total_cost_egp numeric(15,2) DEFAULT '0'::numeric,
    total_paid_egp numeric(15,2) DEFAULT '0'::numeric,
    balance_egp numeric(15,2) DEFAULT '0'::numeric,
    partial_discount_rmb numeric(15,2) DEFAULT '0'::numeric,
    discount_notes text,
    last_payment_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    total_missing_cost_egp numeric(15,2) DEFAULT '0'::numeric
);


--
-- Name: shipments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shipments ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.shipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shipping_companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipping_companies (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    contact_name character varying(255),
    phone character varying(50),
    email character varying(255),
    address text,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: shipping_companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shipping_companies ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.shipping_companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    country character varying(100) DEFAULT 'الصين'::character varying,
    phone character varying(50),
    email character varying(255),
    address text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.suppliers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.suppliers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    first_name character varying,
    last_name character varying,
    role character varying DEFAULT 'مشاهد'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: replit_database_migrations_v1 id; Type: DEFAULT; Schema: _system; Owner: -
--

ALTER TABLE ONLY _system.replit_database_migrations_v1 ALTER COLUMN id SET DEFAULT nextval('_system.replit_database_migrations_v1_id_seq'::regclass);


--
-- Data for Name: replit_database_migrations_v1; Type: TABLE DATA; Schema: _system; Owner: -
--

COPY _system.replit_database_migrations_v1 (id, build_id, deployment_id, statement_count, applied_at) FROM stdin;
1	bf3acf83-2c5a-48e7-8eb3-95d8ed5fd568	4d326259-9fa4-494c-9712-6c1eaf633335	35	2025-12-24 15:41:58.924949+00
2	108aee03-faa6-4d93-b749-9bf8a2b57763	4d326259-9fa4-494c-9712-6c1eaf633335	2	2025-12-27 15:08:40.134148+00
3	91524cbb-b74f-4f12-b125-3df79ccb5d17	4d326259-9fa4-494c-9712-6c1eaf633335	1	2025-12-27 16:56:21.129203+00
4	e755d7b4-2af3-46b3-83bb-7b95c7d6407d	4d326259-9fa4-494c-9712-6c1eaf633335	3	2026-01-03 01:58:14.521595+00
5	3f7f6009-422d-4e90-b4d2-a51b186c9522	4d326259-9fa4-494c-9712-6c1eaf633335	2	2026-01-07 11:10:03.287367+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, entity_type, entity_id, action_type, "timestamp", details) FROM stdin;
1	9892f950-c728-4195-ba21-9fb4cf982734	USER	188b3a6a-625f-4266-b905-954e949106f9	CREATE	2025-12-28 06:24:55.963944	{"role": "مدير"}
2	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	CREATE	2025-12-31 16:45:25.223313	{"status": "جديدة", "shippingCompanyId": null}
3	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 16:46:49.402435	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
4	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	STATUS_CHANGE	2025-12-31 16:46:49.545863	{"to": "في انتظار الشحن", "from": "جديدة"}
5	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 16:47:37.38701	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
6	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 16:49:14.554245	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
7	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 16:56:20.885063	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
8	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:03:07.343628	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
9	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:04:18.097297	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
10	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:04:41.636378	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
11	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:05:27.809384	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
12	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:06:18.263716	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
13	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:06:49.861535	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
14	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:36:51.515252	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
15	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:37:37.251344	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
16	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:40:36.588543	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
17	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:44:44.13176	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
18	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:46:00.54093	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
19	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:46:15.922499	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
20	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:52:32.354907	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
21	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:55:53.745796	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
22	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 17:58:04.343052	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
23	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 18:02:51.074915	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
24	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 18:04:39.848359	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
25	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 18:06:14.564579	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
26	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 18:09:27.869346	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
27	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 18:11:58.296545	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
28	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 18:13:49.926121	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
29	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 18:17:53.593637	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
30	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2025-12-31 18:18:04.40797	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
31	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	2	CREATE	2025-12-31 19:08:26.766113	{"status": "جديدة", "shippingCompanyId": null}
32	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	2	UPDATE	2025-12-31 19:10:40.437452	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
33	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	2	STATUS_CHANGE	2025-12-31 19:10:40.575495	{"to": "في انتظار الشحن", "from": "جديدة"}
34	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	2	UPDATE	2025-12-31 19:10:51.964127	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
35	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	2	UPDATE	2025-12-31 19:15:15.805271	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
36	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	CREATE	2025-12-31 19:28:08.091233	{"status": "جديدة", "shippingCompanyId": null}
37	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:28:31.288746	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
38	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	STATUS_CHANGE	2025-12-31 19:28:31.436023	{"to": "في انتظار الشحن", "from": "جديدة"}
39	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:28:53.849858	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
40	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:28:58.743035	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
41	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:29:19.432525	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
42	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:29:41.430263	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
223	9892f950-c728-4195-ba21-9fb4cf982734	BACKUP	2	CREATE	2026-01-09 17:41:54.361143	{"action": "START_BACKUP"}
43	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:49:52.495804	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
44	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:50:16.222026	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
45	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:50:42.828111	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
46	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:51:03.326897	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
47	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:53:28.966237	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
48	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:54:09.833583	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
49	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:54:40.282441	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
50	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:55:05.77124	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
51	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:55:38.311124	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
52	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:57:07.361577	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
53	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:57:48.92438	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
54	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:58:18.860804	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
55	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 19:59:53.056525	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
56	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:00:20.98736	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
57	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:00:51.091922	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
58	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:01:15.203369	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
59	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:01:42.932042	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
60	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:03:09.635036	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
61	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:04:23.109763	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
62	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:05:59.247665	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
63	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:09:02.149352	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
64	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:11:11.63217	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
65	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:12:22.141643	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
66	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:13:57.609774	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
67	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:15:10.278279	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
68	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:17:10.997568	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
69	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:19:33.686626	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
70	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:21:42.829095	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
71	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:23:26.191906	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
72	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:24:54.024719	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
73	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:26:07.216541	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
74	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:30:34.136934	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
75	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:30:49.776858	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
76	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:32:02.218706	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
77	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:34:16.04174	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
78	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:36:53.441678	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
79	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:36:58.728794	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
80	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:38:30.066705	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
81	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:40:01.232147	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
82	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 20:40:06.752545	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
83	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:00:29.25776	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
84	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:01:06.28004	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
85	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:01:44.530201	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
86	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:02:18.721636	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
87	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:03:11.8707	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
88	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:03:54.042893	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
89	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:04:26.445809	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
90	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:04:51.568304	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
91	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:05:54.032632	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
92	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:06:16.211653	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
93	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:06:36.535698	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
94	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:06:56.175682	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
95	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:07:24.97207	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
96	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:08:59.652234	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
97	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:09:30.003799	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
98	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:09:53.945351	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
99	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:12:15.409565	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
100	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:12:57.391757	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
101	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:13:22.434647	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
102	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:14:50.835313	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
103	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:15:23.826352	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
104	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:15:50.169539	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
105	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:16:20.947019	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
106	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:17:53.339288	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
107	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:18:21.55779	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
108	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:18:53.736055	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
109	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:19:17.974057	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
110	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:19:27.668197	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
111	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:20:49.830736	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
112	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:21:14.808696	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
113	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:21:42.160833	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
114	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:22:15.25381	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
115	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:22:18.33865	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
116	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:22:55.04122	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
117	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:28:45.77575	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
118	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:31:32.976101	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
119	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:43:06.445556	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
120	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2025-12-31 21:47:23.758817	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
121	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2026-01-04 01:56:07.761741	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
122	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2026-01-04 02:01:02.816449	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
123	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2026-01-04 02:02:10.315751	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
158	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:29:56.354048	{"step": 2, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
124	188b3a6a-625f-4266-b905-954e949106f9	shipment	1	missing_pieces_updated	2026-01-04 02:07:00.198509	{"updates": [{"itemId": 3562, "productName": "كولومبي بكره", "unitCostEgp": "854.0000", "missingCostEgp": "854.00", "newMissingPieces": 1, "oldMissingPieces": 0}], "shipmentCode": "1", "newTotalMissingCost": "854.00", "oldTotalMissingCost": "0.00"}
125	188b3a6a-625f-4266-b905-954e949106f9	shipment	1	missing_pieces_updated	2026-01-04 02:07:10.724352	{"updates": [{"itemId": 3581, "productName": "بيور بوست", "unitCostEgp": "406.0000", "missingCostEgp": "406.00", "newMissingPieces": 1, "oldMissingPieces": 0}], "shipmentCode": "1", "newTotalMissingCost": "1260.00", "oldTotalMissingCost": "854.00"}
126	188b3a6a-625f-4266-b905-954e949106f9	shipment	1	missing_pieces_updated	2026-01-04 02:07:27.596128	{"updates": [{"itemId": 3583, "productName": "الكسندر", "unitCostEgp": "385.0000", "missingCostEgp": "385.00", "newMissingPieces": 1, "oldMissingPieces": 0}], "shipmentCode": "1", "newTotalMissingCost": "1645.00", "oldTotalMissingCost": "1260.00"}
127	188b3a6a-625f-4266-b905-954e949106f9	shipment	1	missing_pieces_updated	2026-01-04 02:07:35.558642	{"updates": [{"itemId": 3584, "productName": "ازكس", "unitCostEgp": "434.0000", "missingCostEgp": "434.00", "newMissingPieces": 1, "oldMissingPieces": 0}], "shipmentCode": "1", "newTotalMissingCost": "2079.00", "oldTotalMissingCost": "1645.00"}
128	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	2	UPDATE	2026-01-04 02:13:21.12566	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
129	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	2	UPDATE	2026-01-04 02:20:01.659245	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
130	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 02:38:23.613854	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
131	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 02:41:20.804603	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
132	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 02:45:40.288382	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
133	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 02:45:44.036984	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
134	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 02:48:51.874895	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
135	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 02:48:54.420348	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
136	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 03:03:00.314214	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
137	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 03:03:03.801724	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
138	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 03:06:27.145703	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
139	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 03:09:07.050979	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
140	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 03:13:17.962268	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
141	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	3	UPDATE	2026-01-04 03:13:39.02552	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
142	188b3a6a-625f-4266-b905-954e949106f9	SHIPPING_COMPANY	1	CREATE	2026-01-05 23:46:54.18708	{"name": "speed"}
143	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2026-01-05 23:52:10.107424	{"step": 2, "status": "في انتظار الشحن", "shippingCompanyId": 1, "shippingCompanyChange": {"to": 1, "from": null}}
144	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2026-01-06 00:00:15.233596	{"step": 3, "status": "جاهزة للاستلام", "shippingCompanyId": 1}
145	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	STATUS_CHANGE	2026-01-06 00:00:15.36254	{"to": "جاهزة للاستلام", "from": "في انتظار الشحن"}
146	188b3a6a-625f-4266-b905-954e949106f9	PAYMENT	1	CREATE	2026-01-06 00:05:33.957099	{"amount": "700000", "method": "نقدي", "partyId": 1, "currency": "RMB", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": false}
147	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2026-01-06 04:35:28.017369	{"step": 3, "status": "جاهزة للاستلام", "shippingCompanyId": 1}
148	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	UPDATE	2026-01-06 04:36:51.387297	{"step": 5, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
149	188b3a6a-625f-4266-b905-954e949106f9	SHIPMENT	1	STATUS_CHANGE	2026-01-06 04:36:51.524097	{"to": "مستلمة بنجاح", "from": "جاهزة للاستلام"}
150	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	1	DELETE	2026-01-06 05:52:59.766188	{"amountEgp": "700000.00", "shipmentId": 1, "paymentMethod": "نقدي", "allocationsDeleted": 0}
151	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	2	UPDATE	2026-01-06 05:57:06.721033	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
152	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	2	AUTO_ALLOCATION_CREATED	2026-01-06 06:03:24.455984	{"method": "proportional", "paymentId": 2, "shipmentId": 1, "totalAllocated": "100000.00", "allocationCount": 6}
153	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	2	CREATE	2026-01-06 06:03:24.798265	{"amount": "700000", "method": "نقدي", "partyId": 1, "currency": "RMB", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": false}
154	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	2	UPDATE	2026-01-06 06:08:20.211692	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
155	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:16:40.476549	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
156	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-06 06:29:44.564149	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
157	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:29:54.30722	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
159	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:29:59.429336	{"step": 3, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
160	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:30:06.429809	{"step": 5, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
161	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:31:28.977934	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
162	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:31:33.273877	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
163	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:31:37.573858	{"step": 2, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
164	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:31:45.675492	{"step": 3, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
165	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:31:56.020823	{"step": 5, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
166	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:32:53.541544	{"step": 5, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
167	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:45:22.083944	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
168	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:45:25.274832	{"step": 2, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
169	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:45:28.576392	{"step": 3, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
170	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 06:45:35.349652	{"step": 5, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
171	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	3	CREATE	2026-01-06 06:50:58.762605	{"amount": "500000", "method": "نقدي", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": false}
172	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 07:05:28.529949	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
173	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 07:05:42.183701	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
174	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 07:08:44.307147	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
175	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 07:08:46.717424	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
176	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 07:09:44.56678	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
177	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 07:09:49.504076	{"step": 1, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
178	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	1	UPDATE	2026-01-06 07:11:36.25669	{"step": 5, "status": "مستلمة بنجاح", "shippingCompanyId": 1}
179	9892f950-c728-4195-ba21-9fb4cf982734	EXCHANGE_RATE	2	CREATE	2026-01-06 07:19:25.878993	{"to": "RMB", "from": "USD"}
180	9892f950-c728-4195-ba21-9fb4cf982734	EXCHANGE_RATE	1	CREATE	2026-01-06 07:19:25.880004	{"to": "EGP", "from": "RMB"}
181	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	2	UPDATE	2026-01-06 07:27:47.16161	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
182	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	2	UPDATE	2026-01-06 07:27:51.251207	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
183	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	2	UPDATE	2026-01-06 07:28:03.413747	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
184	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	4	CREATE	2026-01-06 15:49:19.250268	{"amount": "200000", "method": "أخرى", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": true}
185	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	4	DELETE	2026-01-07 22:39:59.548505	{"amountEgp": "200000.00", "shipmentId": 1, "paymentMethod": "أخرى", "allocationsDeleted": 0}
186	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	5	CREATE	2026-01-07 22:41:31.722895	{"amount": "200000", "method": "أخرى", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": true}
187	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	6	AUTO_ALLOCATION_CREATED	2026-01-07 22:47:55.128796	{"method": "proportional", "paymentId": 6, "shipmentId": 1, "totalAllocated": "100000.00", "allocationCount": 6}
188	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	6	CREATE	2026-01-07 22:47:55.384313	{"amount": "700000", "method": "نقدي", "partyId": 1, "currency": "RMB", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": false}
189	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	6	DELETE	2026-01-07 23:02:28.050575	{"amountEgp": "700000.00", "shipmentId": 1, "paymentMethod": "نقدي", "allocationsDeleted": 6}
190	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	7	AUTO_ALLOCATION_CREATED	2026-01-07 23:04:21.889202	{"method": "proportional", "paymentId": 7, "shipmentId": 1, "totalAllocated": "100000.00", "allocationCount": 6}
191	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	7	CREATE	2026-01-07 23:04:22.148378	{"amount": "700000", "method": "نقدي", "partyId": 1, "currency": "RMB", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": false}
192	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	5	DELETE	2026-01-07 23:07:59.302844	{"amountEgp": "200000.00", "shipmentId": 1, "paymentMethod": "أخرى", "allocationsDeleted": 0}
193	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	8	CREATE	2026-01-07 23:35:11.406498	{"amount": "1000", "method": "محفظة الكترونية", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": false}
194	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	8	DELETE	2026-01-07 23:35:26.593703	{"amountEgp": "1000.00", "shipmentId": 1, "paymentMethod": "محفظة الكترونية", "allocationsDeleted": 0}
195	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	9	CREATE	2026-01-08 00:05:14.631969	{"amount": "200000", "method": "أخرى", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": true}
196	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	10	CREATE	2026-01-08 00:10:02.017227	{"amount": "3500", "method": "نواقص", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": false}
197	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	9	DELETE	2026-01-08 00:10:28.928283	{"amountEgp": "200000.00", "shipmentId": 1, "paymentMethod": "أخرى", "allocationsDeleted": 0}
198	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	11	CREATE	2026-01-08 00:19:31.598559	{"amount": "200000", "method": "أخرى", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": true}
199	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	11	DELETE	2026-01-08 00:31:31.761624	{"amountEgp": "200000.00", "shipmentId": 1, "paymentMethod": "أخرى", "allocationsDeleted": 0}
200	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	12	CREATE	2026-01-08 00:33:07.915955	{"amount": "200000", "method": "أخرى", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": true}
201	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	13	CREATE	2026-01-08 00:37:40.890164	{"amount": "33750", "method": "إنستاباي", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": true}
202	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	14	CREATE	2026-01-08 01:22:55.758909	{"amount": "93000", "method": "محفظة الكترونية", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": true}
203	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	15	CREATE	2026-01-08 01:24:34.42837	{"amount": "30000", "method": "نقدي", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": false}
204	9892f950-c728-4195-ba21-9fb4cf982734	PAYMENT	16	CREATE	2026-01-08 01:25:37.695259	{"amount": "375", "method": "أخرى", "partyId": 1, "currency": "EGP", "partyRule": {"required": true, "defaulted": false, "shipmentSuppliers": [2, 10, 16, 18, 8, 15]}, "partyType": "shipping_company", "shipmentId": "1", "hasAttachment": false}
205	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 04:43:04.887245	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
206	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 04:43:08.802305	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
207	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 04:46:35.941907	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
208	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 04:46:39.591719	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
209	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 04:50:01.084133	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
210	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 04:50:03.261105	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
211	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 04:53:28.473831	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
212	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 04:56:24.508002	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
213	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 04:56:30.574395	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
214	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 05:08:37.956263	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
215	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 05:08:42.515666	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
216	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 05:11:56.702939	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
217	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 05:12:01.117803	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
218	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 05:16:29.821709	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
219	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 05:16:32.607933	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
220	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 05:16:39.917501	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
221	9892f950-c728-4195-ba21-9fb4cf982734	SHIPMENT	3	UPDATE	2026-01-08 05:17:21.959851	{"step": 1, "status": "في انتظار الشحن", "shippingCompanyId": null}
222	9892f950-c728-4195-ba21-9fb4cf982734	BACKUP	1	CREATE	2026-01-09 17:21:47.006134	{"action": "START_BACKUP"}
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_jobs (id, job_type, status, progress, output_path, file_size, error, manifest, created_by_user_id, created_at, completed_at) FROM stdin;
2	backup	running	5	\N	\N	\N	\N	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-09 17:41:54.325978	\N
1	backup	completed	100	/replit-objstore-d1a1314e-2786-4b69-9f39-4409faa4f418/backups/2026-01-09T17-22-32-617Z.zip	16282	\N	{"files": ["database.sql", "manifest.json"], "version": "1.0.0", "createdAt": "2026-01-09T17:22:30.924Z", "mediaFiles": {"count": 0, "totalSize": 0}, "databaseStats": {"size": "8808 kB", "tables": 16}}	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-09 17:21:46.838292	2026-01-09 17:22:32.734
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exchange_rates (id, rate_date, from_currency, to_currency, rate_value, source, created_at) FROM stdin;
1	2026-01-06	RMB	EGP	7.000000	تحديث تلقائي	2026-01-06 07:19:25.717976
2	2026-01-06	USD	RMB	7.200000	تحديث تلقائي	2026-01-06 07:19:25.852403
\.


--
-- Data for Name: inventory_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_movements (id, shipment_id, shipment_item_id, product_id, total_pieces_in, unit_cost_rmb, unit_cost_egp, total_cost_egp, movement_date, created_at) FROM stdin;
47	1	5065	\N	149	170.5881	1194.1169	177923.42	2026-01-06	2026-01-06 07:11:35.739553
48	1	5066	\N	150	170.5881	1194.1169	179117.53	2026-01-06	2026-01-06 07:11:35.739553
49	1	5067	\N	150	170.5881	1194.1169	179117.53	2026-01-06	2026-01-06 07:11:35.739553
50	1	5068	\N	75	128.5881	900.1169	67508.77	2026-01-06	2026-01-06 07:11:35.739553
51	1	5069	\N	75	128.5881	900.1169	67508.77	2026-01-06	2026-01-06 07:11:35.739553
52	1	5070	\N	75	128.5881	900.1169	67508.77	2026-01-06	2026-01-06 07:11:35.739553
53	1	5071	\N	75	128.5881	900.1169	67508.77	2026-01-06	2026-01-06 07:11:35.739553
54	1	5072	\N	75	128.5881	900.1169	67508.77	2026-01-06	2026-01-06 07:11:35.739553
55	1	5073	\N	50	135.5881	949.1169	47455.84	2026-01-06	2026-01-06 07:11:35.739553
56	1	5074	\N	50	135.5881	949.1169	47455.84	2026-01-06	2026-01-06 07:11:35.739553
57	1	5075	\N	50	133.5881	935.1169	46755.84	2026-01-06	2026-01-06 07:11:35.739553
58	1	5076	\N	75	123.5881	865.1169	64883.77	2026-01-06	2026-01-06 07:11:35.739553
59	1	5077	\N	150	123.5881	865.1169	129767.53	2026-01-06	2026-01-06 07:11:35.739553
60	1	5078	\N	75	123.5881	865.1169	64883.77	2026-01-06	2026-01-06 07:11:35.739553
61	1	5079	\N	475	161.5881	1131.1169	537280.52	2026-01-06	2026-01-06 07:11:35.739553
62	1	5080	\N	350	123.5881	865.1169	302790.91	2026-01-06	2026-01-06 07:11:35.739553
63	1	5081	\N	100	138.5881	970.1169	97011.69	2026-01-06	2026-01-06 07:11:35.739553
64	1	5082	\N	150	106.5881	746.1169	111917.53	2026-01-06	2026-01-06 07:11:35.739553
65	1	5083	\N	150	98.5881	690.1169	103517.53	2026-01-06	2026-01-06 07:11:35.739553
66	1	5084	\N	249	106.5881	746.1169	185783.11	2026-01-06	2026-01-06 07:11:35.739553
67	1	5085	\N	100	103.5881	725.1169	72511.69	2026-01-06	2026-01-06 07:11:35.739553
68	1	5086	\N	224	103.5881	725.1169	162426.18	2026-01-06	2026-01-06 07:11:35.739553
69	1	5087	\N	299	110.5881	774.1169	231460.95	2026-01-06	2026-01-06 07:11:35.739553
\.


--
-- Data for Name: payment_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_allocations (id, payment_id, shipment_id, supplier_id, component, currency, allocated_amount, created_by, created_at) FROM stdin;
1	2	1	2	تكلفة البضاعة	RMB	67490.80	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-06 06:03:24.455984
2	2	1	10	تكلفة البضاعة	RMB	10180.34	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-06 06:03:24.455984
3	2	1	16	تكلفة البضاعة	RMB	5623.42	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-06 06:03:24.455984
4	2	1	18	تكلفة البضاعة	RMB	6282.72	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-06 06:03:24.455984
5	2	1	8	تكلفة البضاعة	RMB	5623.42	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-06 06:03:24.455984
6	2	1	15	تكلفة البضاعة	RMB	4799.30	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-06 06:03:24.455984
13	7	1	2	تكلفة البضاعة	RMB	67490.80	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-07 23:04:21.889202
14	7	1	10	تكلفة البضاعة	RMB	10180.34	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-07 23:04:21.889202
15	7	1	16	تكلفة البضاعة	RMB	5623.42	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-07 23:04:21.889202
16	7	1	18	تكلفة البضاعة	RMB	6282.72	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-07 23:04:21.889202
17	7	1	8	تكلفة البضاعة	RMB	5623.42	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-07 23:04:21.889202
18	7	1	15	تكلفة البضاعة	RMB	4799.30	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-07 23:04:21.889202
\.


--
-- Data for Name: product_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_types (id, name, description, is_active, created_at, updated_at) FROM stdin;
1	كوتش	\N	t	2025-12-31 16:46:14.707789	2025-12-31 16:46:14.707789
2	جزمه جلد	\N	t	2025-12-31 16:46:32.169398	2025-12-31 16:46:32.169398
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, type, default_image_url, default_supplier_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (sid, sess, expire) FROM stdin;
Kv0SGxEGBY_7a1ypGGccMDd9xLXFPUDS	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-13T04:02:57.659Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": "9892f950-c728-4195-ba21-9fb4cf982734"}}	2026-01-13 04:20:11
ixuKcmJpT3HHfx1pmQhzX4U7w29SYSWe	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-13T05:55:32.681Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": "9892f950-c728-4195-ba21-9fb4cf982734"}}	2026-01-13 06:01:40
BCHK4CqTqwuLf3OYq-0HGPd3F8b8VGGa	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-15T00:18:20.745Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": "9892f950-c728-4195-ba21-9fb4cf982734"}}	2026-01-15 19:44:27
v8RpPFBV6rH-ZLvUvBpYR1VovClaaIRU	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-05T02:15:15.015Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": "188b3a6a-625f-4266-b905-954e949106f9"}}	2026-01-10 03:43:22
xP2PHBhBanGYYx3YD9qsxCLenT9vfClr	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-13T06:29:22.592Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": "9892f950-c728-4195-ba21-9fb4cf982734"}}	2026-01-13 06:45:39
ZHdQsOE66TX4VxOKuRbVN4e7tsLwaShc	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-10T00:19:30.918Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": "9892f950-c728-4195-ba21-9fb4cf982734"}}	2026-01-16 17:31:50
9DIwbB06o8D_9lvtpOOfh9_N9wZZemmS	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-16T17:41:34.847Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": "9892f950-c728-4195-ba21-9fb4cf982734"}}	2026-01-16 17:41:55
aUtBbWhT0gnsDDAfw7bD5Y8E72NybNE_	{"cookie": {"path": "/", "secure": true, "expires": "2026-01-05T01:50:37.935Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": "188b3a6a-625f-4266-b905-954e949106f9"}}	2026-01-11 03:13:47
\.


--
-- Data for Name: shipment_customs_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipment_customs_details (id, shipment_id, total_customs_cost_egp, total_takhreeg_cost_egp, customs_invoice_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shipment_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipment_items (id, shipment_id, supplier_id, product_id, product_type_id, product_name, description, country_of_origin, image_url, cartons_ctn, pieces_per_carton_pcs, total_pieces_cou, purchase_price_per_piece_pri_rmb, total_purchase_cost_rmb, customs_cost_per_carton_egp, total_customs_cost_egp, takhreeg_cost_per_carton_egp, total_takhreeg_cost_egp, created_at, updated_at, line_no, missing_pieces, missing_cost_egp) FROM stdin;
6198	3	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/9357a551-f638-46a5-b18b-1482c6481f26	3	25	75	80.0000	6000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	1	0	0.00
6199	3	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/e8568911-b132-47a2-a3c6-971d3abee41b	3	25	75	80.0000	6000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	2	0	0.00
6200	3	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/6eab3cc6-b3b7-44b3-9b7c-e36985f527eb	3	25	75	80.0000	6000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	3	0	0.00
6201	3	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/eab30e50-eda9-4826-973d-66b60ff7b592	3	25	75	80.0000	6000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	4	0	0.00
6202	3	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/81cc0693-7c73-46ee-b5e6-ecf690ba0e73	3	25	75	80.0000	6000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	5	0	0.00
6203	3	2	\N	1	كيومنت 2	\N	الصين	/objects/uploads/925f7dea-09da-488c-9832-5fbc4958ea0f	2	25	50	110.0000	5500.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	6	0	0.00
6204	3	2	\N	1	كيومنت 2	\N	الصين	/objects/uploads/f54ec24c-7595-433f-959f-6b127c3a3875	2	25	50	110.0000	5500.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	7	0	0.00
6205	3	2	\N	1	كيومنت 2	\N	الصين	/objects/uploads/e64f4d99-0056-4495-93b1-538f0ed07a11	2	25	50	110.0000	5500.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	8	0	0.00
6206	3	2	\N	1	كيومنت 2	\N	الصين	/objects/uploads/fe66576f-48fb-48f1-b8de-947eb92bb69e	2	25	50	110.0000	5500.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	9	0	0.00
6207	3	2	\N	1	يزي	\N	الصين	/objects/uploads/32e307b4-44e7-4911-ad78-ce840fcd8729	2	25	50	75.0000	3750.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	10	0	0.00
6208	3	2	\N	1	يزي	\N	الصين	/objects/uploads/71939487-4703-4e21-86e5-7ac7d54a0360	2	25	50	75.0000	3750.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	11	0	0.00
6209	3	2	\N	1	يزي	\N	الصين	/objects/uploads/200e88bf-ee99-40f2-b6fb-603b9cb50b28	2	25	50	75.0000	3750.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	12	0	0.00
6210	3	2	\N	1	يزي	\N	الصين	/objects/uploads/c373b20c-1854-496e-bdbe-d19da22d1ae9	3	25	75	75.0000	5625.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	13	0	0.00
6211	3	2	\N	1	يزي	\N	الصين	/objects/uploads/eccd56ab-7adc-473d-8407-1006adf1a317	3	25	75	75.0000	5625.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	14	0	0.00
6212	3	2	\N	1	كوليمبي بكر	\N	الصين	/objects/uploads/09caf02d-0880-4cf8-84a8-d08d3f81d81e	2	25	50	121.0000	6050.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	15	0	0.00
6213	3	2	\N	1	كوليمبي بكر	\N	الصين	/objects/uploads/c388bb2b-310e-44a8-8fce-ad3f58b54d54	2	25	50	121.0000	6050.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	16	0	0.00
6214	3	2	\N	1	كوليمبي بكر	\N	الصين	/objects/uploads/0833a894-0d4b-44a1-ba5e-3278e6a31086	2	25	50	121.0000	6050.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	17	0	0.00
6215	3	2	\N	1	اديستار جديده	\N	الصين	/objects/uploads/0a0233ef-e253-4c45-8d18-cd77e80d0117	2	25	50	113.0000	5650.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	18	0	0.00
6216	3	2	\N	1	اديستار جديده	\N	الصين	/objects/uploads/b3584b2c-b4aa-453c-8f5e-bdeea5b3ead4	2	25	50	113.0000	5650.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	19	0	0.00
6217	3	2	\N	1	اديستار جديده	\N	الصين	/objects/uploads/3b5011be-7e30-4b24-982e-ca8c585cdade	2	25	50	113.0000	5650.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	20	0	0.00
6218	3	2	\N	1	اديستار جديده	\N	الصين	/objects/uploads/d80fa881-3a76-4ef2-a223-6fcabc0019ba	2	25	50	113.0000	5650.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	21	0	0.00
6219	3	2	\N	1	اديستار جديده	\N	الصين	/objects/uploads/8298db48-e0aa-47c4-9d44-51f555a9ce14	2	25	50	113.0000	5650.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	22	0	0.00
6220	3	12	\N	1	كوليمبي 	\N	الصين	/objects/uploads/446f02dc-feb4-48e4-80a6-d360a3e1cb61	9	25	225	57.0000	12825.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	23	0	0.00
6221	3	8	\N	1	بيور بوست	\N	الصين	/objects/uploads/59eddd8b-eeb8-4be9-944d-d4b800e6041f	6	25	150	55.0000	8250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	24	0	0.00
6222	3	8	\N	1	بيور بوست	\N	الصين	/objects/uploads/2d7b610e-472e-4da6-87d0-bbdcab261d12	8	25	200	53.0000	10600.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	25	0	0.00
6223	3	18	\N	1	سمبا	\N	الصين	/objects/uploads/fb66b45c-e0de-44fd-b688-769aeabb2a40	4	25	100	50.0000	5000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	26	0	0.00
6224	3	18	\N	1	نيو بلانس ٥٣٠ حريمي	\N	الصين	/objects/uploads/f9dfbf87-8955-4a2a-9ffb-cacac18e48c2	6	25	150	55.0000	8250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	27	0	0.00
6225	3	18	\N	1	نيو بلانس ٥٣٠ رجالي	\N	الصين	/objects/uploads/cdf5f44d-5899-47d3-a274-92eec0f5edfc	8	25	200	55.0000	11000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	28	0	0.00
6226	3	18	\N	1	ادزيرو 	\N	الصين	/objects/uploads/c5af0d78-692b-4ef3-b0ea-34cff3511b8f	15	25	375	67.0000	25125.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	29	0	0.00
6227	3	16	\N	1	تي ان 1	\N	الصين	/objects/uploads/5bb13bdb-4af6-4a1c-8fa0-7256574d67cb	3	25	75	53.0000	3975.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	30	0	0.00
6228	3	9	\N	1	ازكس	\N	الصين	/objects/uploads/ae4ce014-2d13-4831-b11e-72f9ed5fa529	9	24	216	80.0000	17280.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	31	0	0.00
6229	3	17	\N	1	اديداس	\N	الصين	/objects/uploads/28eb2a21-546e-48a1-9581-126513be94c4	13	25	325	75.0000	24375.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	32	0	0.00
6230	3	6	\N	1	باسكت	\N	الصين	/objects/uploads/713c4447-f76a-4ff4-873f-bf6298b050d1	8	25	200	60.0000	12000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	33	0	0.00
6231	3	11	\N	1	ايرفورس	\N	الصين	/objects/uploads/276e99ab-8376-48e2-9071-2dc6825ec483	5	25	125	43.0000	5375.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	34	0	0.00
6232	3	20	\N	1	تي ان 3	\N	الصين	/objects/uploads/7586f761-faf9-4983-b818-d34cd5d95bac	8	25	200	85.0000	17000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	35	0	0.00
6233	3	10	\N	1	ادزيرو 2	\N	الصين	/objects/uploads/2eb65893-9c7a-4e38-9900-36c20653307d	10	25	250	83.0000	20750.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	36	0	0.00
6234	3	10	\N	1	كوليمبي	\N	الصين	/objects/uploads/0ca4e97b-23db-4573-aa8f-ccf6e6c8f673	3	25	75	100.0000	7500.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	37	0	0.00
6235	3	13	\N	1	كامبوس	\N	الصين	/objects/uploads/24745345-ea15-4cad-952b-17008f988217	4	24	96	45.0000	4320.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	38	0	0.00
6236	3	4	\N	1	هوكا	\N	الصين	/objects/uploads/91a75711-f2c9-4960-a461-f3906dab017a	10	25	250	68.0000	17000.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	39	0	0.00
6237	3	21	\N	1	كامبوس	\N	الصين	/objects/uploads/b977dfcc-40ab-4b79-b838-738cffe267cb	2	25	50	50.0000	2500.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	40	0	0.00
6238	3	1	\N	1	جوردن 4 رجالي	\N	الصين	/objects/uploads/f50ce69d-9da1-4d52-a4d4-94653cd32ea5	4	35	140	90.0000	12600.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	41	0	0.00
6239	3	1	\N	1	جوردن 4 رجالي	\N	الصين	/objects/uploads/880c1f86-7c32-47af-972c-0f9d60121bdc	2	35	70	90.0000	6300.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	42	0	0.00
6240	3	1	\N	1	جوردن 4 رجالي	\N	الصين	/objects/uploads/58e9f6ba-98d6-4a4c-b4dc-937dbebc2d51	2	35	70	90.0000	6300.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	43	0	0.00
6241	3	1	\N	1	جوردن 4 رجالي	\N	الصين	/objects/uploads/2767f340-12fd-4bcf-b79c-324eb1408ff7	2	35	70	90.0000	6300.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	44	0	0.00
6242	3	1	\N	1	جوردن 4 محير	\N	الصين	/objects/uploads/0a22da58-4e9d-4e11-8cbe-ca0b0daac488	1	25	25	90.0000	2250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	45	0	0.00
6243	3	1	\N	1	جوردن 4 محير	\N	الصين	/objects/uploads/783d99a7-76ca-42cf-b24a-6fd5805bdb87	1	25	25	90.0000	2250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	46	0	0.00
6244	3	1	\N	1	جوردن 4 محير	\N	الصين	/objects/uploads/b367ce6c-59f1-4228-a674-78963255f484	1	25	25	90.0000	2250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	47	0	0.00
6245	3	1	\N	1	اديداس	\N	الصين	/objects/uploads/3e769c69-93c7-4a31-b163-71ffafef473d	2	25	50	125.0000	6250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	48	0	0.00
6246	3	1	\N	1	اديداس	\N	الصين	/objects/uploads/38775850-0f04-4389-a959-ab4aa0676231	2	25	50	125.0000	6250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	49	0	0.00
6247	3	1	\N	1	اديداس	\N	الصين	/objects/uploads/a24ac0ec-3295-48ae-89fb-6f14ef80870e	2	25	50	125.0000	6250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	50	0	0.00
6248	3	1	\N	1	اديداس	\N	الصين	/objects/uploads/90bcd456-7a69-4a63-8a02-e13e0985a66f	2	25	50	125.0000	6250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	51	0	0.00
6249	3	1	\N	1	تمبر لاند شراب	\N	الصين	/objects/uploads/0efd615b-1b51-40c1-902c-ac770a983c22	2	25	50	105.0000	5250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	52	0	0.00
6250	3	1	\N	1	تمبر لاند شراب	\N	الصين	/objects/uploads/3a20417c-43b7-4b7b-a178-9973a3dccdbd	3	25	75	105.0000	7875.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	53	0	0.00
6251	3	1	\N	1	تمبر لاند شراب	\N	الصين	/objects/uploads/d3d08023-ff13-4f8e-8450-d448a382ce70	2	25	50	105.0000	5250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	54	0	0.00
6252	3	1	\N	1	كيومانت 1	\N	الصين	/objects/uploads/fe07e474-4280-4b35-8f1b-997030e7e6df	5	25	125	106.0000	13250.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	55	0	0.00
6253	3	1	\N	1	كيومانت 1	\N	الصين	/objects/uploads/8b2f257f-92b5-4ad6-a2b7-d305fc425ef2	2	25	50	106.0000	5300.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	56	0	0.00
6254	3	1	\N	1	كيومانت 1	\N	الصين	/objects/uploads/6364a9e6-6127-4435-96d7-adf578755991	2	25	50	106.0000	5300.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	57	0	0.00
6255	3	1	\N	1	نورث فيث	\N	الصين	/objects/uploads/a6f03e17-63c5-49cc-9995-863b312338e4	2	25	50	102.0000	5100.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	58	0	0.00
6256	3	1	\N	1	نورث فيث	\N	الصين	/objects/uploads/aa99b12a-2e84-472e-a2dd-0c7d3dff0782	2	25	50	102.0000	5100.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	59	0	0.00
6257	3	1	\N	1	نورث فيث	\N	الصين	/objects/uploads/34864d22-c092-4673-bd95-7106618cc858	2	25	50	102.0000	5100.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	60	0	0.00
6258	3	1	\N	1	نورث فيث	\N	الصين	/objects/uploads/d57d65fb-fe97-4cd4-a0d2-bd56aca1f6e7	2	25	50	102.0000	5100.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	61	0	0.00
6259	3	1	\N	1	اديداس	\N	الصين	/objects/uploads/4c6bdcd8-050d-4416-9104-0ebf34677114	2	25	50	94.0000	4700.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	62	0	0.00
6260	3	1	\N	1	اديداس	\N	الصين	/objects/uploads/9d48bbaa-ec75-4e87-98f2-dc308e4ad2b9	2	25	50	94.0000	4700.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	63	0	0.00
6261	3	1	\N	1	اديداس	\N	الصين	/objects/uploads/ca962e4a-59c3-4a82-8590-bfa4345a1d1f	2	25	50	94.0000	4700.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	64	0	0.00
6262	3	1	\N	1	اديداس	\N	الصين	/objects/uploads/cb76bd2a-7719-422c-81f4-bf013fbd0dab	2	25	50	94.0000	4700.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	65	0	0.00
6263	3	1	\N	1	تمبر لاند برباط	\N	الصين	/objects/uploads/6315f584-d6ce-4df0-a6fb-4d2217796204	2	25	50	104.0000	5200.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	66	0	0.00
6264	3	1	\N	1	تمبر لاند برباط	\N	الصين	/objects/uploads/9009b82c-e970-4dba-bd2a-17b7099f802a	2	25	50	104.0000	5200.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	67	0	0.00
6265	3	1	\N	1	تمبر لاند برباط	\N	الصين	/objects/uploads/8e1924f1-22a9-4cc7-97c1-d0c198563a56	2	25	50	104.0000	5200.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	68	0	0.00
6266	3	1	\N	1	تمبر لاند برباط	\N	الصين	/objects/uploads/f12512d3-9fc0-4d81-9205-b152dfc9b205	1	25	25	104.0000	2600.00	\N	0.00	\N	0.00	2026-01-08 05:17:21.473878	2026-01-08 05:17:21.473878	69	0	0.00
5092	2	16	\N	1	شوكس	\N	الصين	/objects/uploads/fc71ab58-d42e-4ad6-95ec-6c6f2558545d	5	25	125	90.0000	11250.00	\N	0.00	\N	0.00	2026-01-06 07:28:03.057825	2026-01-06 07:28:03.057825	1	0	0.00
5093	2	19	\N	1	الكسندر ميرور	\N	الصين	/objects/uploads/60663ad2-d763-487a-bc05-43864ed5b274	20	12	240	80.0000	19200.00	\N	0.00	\N	0.00	2026-01-06 07:28:03.057825	2026-01-06 07:28:03.057825	2	0	0.00
5065	1	2	\N	1	كولومبي بكره	\N	الصين	/objects/uploads/ec7aae22-932b-4e30-81fa-4583f08e5a5e	6	25	150	122.0000	18300.00	245.00	36750.00	250.00	1500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	1	1	1194.12
5066	1	2	\N	1	كولومبي بكره	\N	الصين	/objects/uploads/a2602757-8f46-4478-8057-8ffa5967efa5	6	25	150	122.0000	18300.00	245.00	36750.00	250.00	1500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	2	0	0.00
5067	1	2	\N	1	كولومبي بكره	\N	الصين	/objects/uploads/2502526c-3060-440c-86e9-81054f1bbce8	6	25	150	122.0000	18300.00	245.00	36750.00	250.00	1500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	3	0	0.00
5068	1	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/0f3d672f-89ce-407a-9d2f-ed1b09180234	3	25	75	80.0000	6000.00	245.00	18375.00	250.00	750.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	4	0	0.00
5069	1	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/2a46fafc-2d16-48bf-82e1-6d604e121a7a	3	25	75	80.0000	6000.00	245.00	18375.00	250.00	750.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	5	0	0.00
5070	1	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/78ce9fbf-582f-4953-ab9d-a589c1028a5b	3	25	75	80.0000	6000.00	245.00	18375.00	250.00	750.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	6	0	0.00
5071	1	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/6fe9f2ba-6acc-46e0-a340-ce6e5dc07f3c	3	25	75	80.0000	6000.00	245.00	18375.00	250.00	750.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	7	0	0.00
5072	1	2	\N	1	اديستار 1	\N	الصين	/objects/uploads/74a98ac2-25d3-4ecc-84df-05309945814e	3	25	75	80.0000	6000.00	245.00	18375.00	250.00	750.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	8	0	0.00
5073	1	2	\N	1	ادزيرو اديداس	\N	الصين	/objects/uploads/c96fa650-601d-485d-a0b0-c58f47a3b41b	2	25	50	87.0000	4350.00	245.00	12250.00	250.00	500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	9	0	0.00
5074	1	2	\N	1	ادزيرو اديداس	\N	الصين	/objects/uploads/536ebee7-1471-449d-92b9-08438ad33ab0	2	25	50	87.0000	4350.00	245.00	12250.00	250.00	500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	10	0	0.00
5075	1	2	\N	1	كرستيانو	\N	الصين	/objects/uploads/87bcfa61-d4ff-40e9-90db-1b5fd79bfddd	2	25	50	85.0000	4250.00	245.00	12250.00	250.00	500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	11	0	0.00
5076	1	2	\N	1	جوردن4	\N	الصين	/objects/uploads/59c6bbf0-e4b3-45c7-9361-647592ce3900	3	25	75	75.0000	5625.00	245.00	18375.00	250.00	750.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	12	0	0.00
5077	1	2	\N	1	جوردن4	\N	الصين	/objects/uploads/f6cd7ad3-6e39-4719-9d63-a6b17854baa8	6	25	150	75.0000	11250.00	245.00	36750.00	250.00	1500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	13	0	0.00
5078	1	2	\N	1	جوردن 4	\N	الصين	/objects/uploads/ad7ca5cd-501f-4702-b64d-56a6218e8605	3	25	75	75.0000	5625.00	245.00	18375.00	250.00	750.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	14	0	0.00
5079	1	2	\N	1	اديستار 2	\N	الصين	/objects/uploads/d0f4f590-58d4-4f1e-9c7d-dd4e7f28bf31	19	25	475	113.0000	53675.00	245.00	116375.00	250.00	4750.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	15	0	0.00
5080	1	10	\N	1	ادزيرو 	\N	الصين	/objects/uploads/1db0079c-439b-4109-a424-3754fcc6e76d	14	25	350	75.0000	26250.00	245.00	85750.00	250.00	3500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	16	0	0.00
5081	1	16	\N	1	شوكس	\N	الصين	/objects/uploads/08d13664-3666-432e-b888-c9cfc01cfa00	4	25	100	90.0000	9000.00	245.00	24500.00	250.00	1000.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	17	0	0.00
5082	1	18	\N	1	نيو بلانس 530	\N	الصين	/objects/uploads/6e91bd78-754d-478f-95d0-ac868787b283	6	25	150	58.0000	8700.00	245.00	36750.00	250.00	1500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	18	0	0.00
5083	1	18	\N	1	سمبا	\N	الصين	/objects/uploads/4aa3b03f-e8b6-44ab-8471-f671986c1b0b	6	25	150	50.0000	7500.00	245.00	36750.00	250.00	1500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	19	0	0.00
5084	1	8	\N	1	بيور بوست	\N	الصين	/objects/uploads/d10add8e-23fb-44d8-b056-f17b850f70f8	10	25	250	58.0000	14500.00	245.00	61250.00	250.00	2500.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	20	1	746.12
5085	1	16	\N	1	تي ان 1	\N	الصين	/objects/uploads/6e076e89-14bd-4cd4-9100-4fd5ceb951a6	4	25	100	55.0000	5500.00	245.00	24500.00	250.00	1000.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	21	0	0.00
5086	1	15	\N	1	الكسندر	\N	الصين	/objects/uploads/6db631a5-b9b3-4f79-97fa-8241d4c8c7df	9	25	225	55.0000	12375.00	245.00	55125.00	250.00	2250.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	22	1	725.12
5087	1	\N	\N	1	ازكس	\N	الصين	/objects/uploads/6bdf7e3f-da51-4db9-b99a-5a22d680ea25	12	25	300	62.0000	18600.00	245.00	73500.00	250.00	3000.00	2026-01-06 07:11:35.739553	2026-01-06 07:11:35.739553	23	1	774.12
\.


--
-- Data for Name: shipment_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipment_payments (id, shipment_id, party_type, party_id, payment_date, payment_currency, amount_original, exchange_rate_to_egp, amount_egp, cost_component, payment_method, cash_receiver_name, reference_number, note, attachment_url, attachment_mime_type, attachment_size, attachment_original_name, attachment_uploaded_at, created_by_user_id, created_at, updated_at) FROM stdin;
2	1	shipping_company	1	2026-01-06 00:00:00	RMB	100000.00	7.0000	700000.00	تكلفة البضاعة	نقدي	محمود	\N	فى المكتب 	\N	\N	\N	\N	\N	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-06 06:03:24.455984	2026-01-06 06:03:24.455984
3	1	shipping_company	1	2026-01-06 00:00:00	EGP	500000.00	\N	500000.00	الجمرك	نقدي	محمود	\N	\N	\N	\N	\N	\N	\N	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-06 06:50:58.584316	2026-01-06 06:50:58.584316
7	1	shipping_company	1	2026-01-07 00:00:00	RMB	100000.00	7.0000	700000.00	تكلفة البضاعة	نقدي	محمود	\N	في المكتب	\N	\N	\N	\N	\N	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-07 23:04:21.889202	2026-01-07 23:04:21.889202
10	1	shipping_company	1	2026-01-08 00:00:00	EGP	3500.00	\N	3500.00	الجمرك	نواقص	\N	\N	4 قطع عجز	\N	\N	\N	\N	\N	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-08 00:10:01.836903	2026-01-08 00:10:01.836903
12	1	shipping_company	1	2026-01-08 00:00:00	EGP	200000.00	\N	200000.00	الجمرك	أخرى	\N	\N	تحويلات لي محمود	/objects/uploads/421cb310-c032-435f-bc20-ce6c09864bc3	image/png	447270	‏لقطة الشاشة 2026-01-06 في 5.48.36 م.png	2026-01-08 00:33:07.732	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-08 00:33:07.744525	2026-01-08 00:33:07.744525
13	1	shipping_company	1	2026-01-08 00:00:00	EGP	33750.00	\N	33750.00	التخريج	إنستاباي	\N	\N	تصفية التخريج 	/objects/uploads/80b61e29-3477-449c-b97d-71e88c8043ca	image/jpeg	56914	WhatsApp Image‏ 2026-01-08 at 02.36.58.jpeg	2026-01-08 00:37:40.711	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-08 00:37:40.721703	2026-01-08 00:37:40.721703
14	1	shipping_company	1	2026-01-08 00:00:00	EGP	93000.00	\N	93000.00	الجمرك	محفظة الكترونية	\N	\N	تحويل في المكتب	/objects/uploads/736aabe6-9d7a-4a18-a5d0-51b062609508	image/png	642358	‏لقطة الشاشة 2026-01-08 في 3.21.14 ص.png	2026-01-08 01:22:55.566	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-08 01:22:55.578264	2026-01-08 01:22:55.578264
15	1	shipping_company	1	2026-01-08 00:00:00	EGP	30000.00	\N	30000.00	الجمرك	نقدي	محمود	\N	في المكتب 	\N	\N	\N	\N	\N	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-08 01:24:34.263856	2026-01-08 01:24:34.263856
16	1	shipping_company	1	2026-01-08 00:00:00	EGP	375.00	\N	375.00	الجمرك	أخرى	\N	\N	خصم بمعرفه محمود	\N	\N	\N	\N	\N	9892f950-c728-4195-ba21-9fb4cf982734	2026-01-08 01:25:37.544487	2026-01-08 01:25:37.544487
\.


--
-- Data for Name: shipment_shipping_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipment_shipping_details (id, shipment_id, total_purchase_cost_rmb, commission_rate_percent, commission_value_rmb, commission_value_egp, shipping_area_sqm, shipping_cost_per_sqm_usd_original, total_shipping_cost_usd_original, total_shipping_cost_rmb, total_shipping_cost_egp, shipping_date, rmb_to_egp_rate_at_shipping, usd_to_rmb_rate_at_shipping, source_of_rates, rates_updated_at, created_at, updated_at) FROM stdin;
1	1	276450.00	5.00	13822.50	96757.50	21.00	180.00	3780.00	27216.00	190512.00	2025-12-31	7.0000	7.2000	\N	\N	2025-12-31 16:46:49.095517	2026-01-06 07:11:35.968
28	2	30450.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2025-12-31	7.0000	7.2000	\N	\N	2025-12-31 19:10:40.112346	2026-01-06 07:28:03.267
31	3	496900.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2025-12-31	7.0000	7.2000	\N	\N	2025-12-31 19:28:30.97567	2026-01-08 05:17:21.818
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipments (id, shipment_code, shipment_name, purchase_date, status, invoice_customs_date, shipping_company_id, created_by_user_id, purchase_cost_rmb, purchase_cost_egp, purchase_rmb_to_egp_rate, commission_cost_rmb, commission_cost_egp, shipping_cost_rmb, shipping_cost_egp, customs_cost_egp, takhreeg_cost_egp, final_total_cost_egp, total_paid_egp, balance_egp, partial_discount_rmb, discount_notes, last_payment_date, created_at, updated_at, total_missing_cost_egp) FROM stdin;
2	2	كوتش	2025-11-26	في انتظار الشحن	\N	\N	188b3a6a-625f-4266-b905-954e949106f9	30450.00	213150.00	7.0000	0.00	0.00	0.00	0.00	0.00	0.00	213150.00	0.00	213150.00	0.00		\N	2025-12-31 19:08:26.603847	2026-01-06 07:28:03.358	0.00
1	1	كوتش	2025-11-04	مستلمة بنجاح	\N	1	188b3a6a-625f-4266-b905-954e949106f9	276450.00	1935150.00	7.0000	13822.50	96757.50	27216.00	190512.00	826875.00	33750.00	3083044.50	2260625.00	822419.50	0.00		2026-01-08 00:00:00	2025-12-31 16:45:25.057322	2026-01-08 01:25:37.641	3439.48
3	3	كوتش	2025-12-11	في انتظار الشحن	\N	\N	188b3a6a-625f-4266-b905-954e949106f9	496900.00	3478300.00	7.0000	0.00	0.00	0.00	0.00	0.00	0.00	3478300.00	0.00	3478300.00	0.00		\N	2025-12-31 19:28:07.918966	2026-01-08 05:17:21.905	0.00
\.


--
-- Data for Name: shipping_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipping_companies (id, name, contact_name, phone, email, address, notes, is_active, created_at, updated_at) FROM stdin;
1	speed	\N	\N	\N	\N	\N	t	2026-01-05 23:46:54.153388	2026-01-05 23:46:54.153388
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, description, country, phone, email, address, is_active, created_at, updated_at) FROM stdin;
1	sue	\N	الصين	\N	\N	\N	t	2025-12-27 15:15:20.683991	2025-12-27 15:15:20.683991
2	collin	\N	الصين	\N	\N	مول ماكدونالدز	t	2025-12-31 16:28:19.472473	2025-12-31 16:28:19.472473
3	sasa	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:28:55.601749	2025-12-31 16:28:55.601749
4	cc	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:29:12.073089	2025-12-31 16:29:12.073089
5	marisa	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:29:49.047703	2025-12-31 16:29:49.047703
6	Aicha	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:30:53.175802	2025-12-31 16:30:53.175802
7	jenny	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:31:34.509236	2025-12-31 16:31:34.509236
8	Alina البنت الحلوه	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:32:31.64485	2025-12-31 16:32:31.64485
9	pin pin	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:32:53.846984	2025-12-31 16:32:53.846984
10	yurong	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:33:43.765724	2025-12-31 16:33:43.765724
11	wjj	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:34:07.203796	2025-12-31 16:34:07.203796
12	tony	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:34:26.981922	2025-12-31 16:34:26.981922
13	Mr li	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:35:14.955207	2025-12-31 16:35:14.955207
14	cindy	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:35:36.437532	2025-12-31 16:35:36.437532
15	zhuliya	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:36:11.272538	2025-12-31 16:36:11.272538
16	xiao المجنونه	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:38:14.515634	2025-12-31 16:38:14.515634
17	الصيني علي السلم	\N	الصين	\N	\N	tong tong	t	2025-12-31 16:39:02.55794	2025-12-31 16:39:02.55794
18	linna	\N	الصين	\N	\N	tong tong	t	2025-12-31 18:03:59.859808	2025-12-31 18:03:59.859808
19	Alice	\N	الصين	\N	\N	tong tong	t	2025-12-31 19:14:57.854943	2025-12-31 19:14:57.854943
20	sasa	\N	الصين	\N	\N	tong tong	t	2025-12-31 20:25:35.907007	2025-12-31 20:25:35.907007
21	MAMA GRACE	\N	الصين	\N	\N	tong tong	t	2025-12-31 20:39:29.582257	2025-12-31 20:39:29.582257
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password, first_name, last_name, role, created_at, updated_at) FROM stdin;
9892f950-c728-4195-ba21-9fb4cf982734	root	$2b$10$0MsxXixAwMO3X4ETra9qA.BWO5Tk.HzKLcbSc4pOPK2E/0mQTk1Zi	المدير	الرئيسي	مدير	2025-12-24 15:44:25.596607	2025-12-24 15:44:25.596607
188b3a6a-625f-4266-b905-954e949106f9	MFoda	$2b$10$kiVkdpOdEl599afE0QkvwuNnlmsm.6M2d8qj3GlpLqevBoSv1gsiu	Mohamed	Fouda	مدير	2025-12-28 06:24:55.93262	2025-12-28 06:24:55.93262
\.


--
-- Name: replit_database_migrations_v1_id_seq; Type: SEQUENCE SET; Schema: _system; Owner: -
--

SELECT pg_catalog.setval('_system.replit_database_migrations_v1_id_seq', 5, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 223, true);


--
-- Name: backup_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backup_jobs_id_seq', 2, true);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.exchange_rates_id_seq', 2, true);


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_movements_id_seq', 69, true);


--
-- Name: payment_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_allocations_id_seq', 18, true);


--
-- Name: product_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_types_id_seq', 2, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: shipment_customs_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shipment_customs_details_id_seq', 1, false);


--
-- Name: shipment_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shipment_items_id_seq', 6266, true);


--
-- Name: shipment_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shipment_payments_id_seq', 16, true);


--
-- Name: shipment_shipping_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shipment_shipping_details_id_seq', 179, true);


--
-- Name: shipments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shipments_id_seq', 3, true);


--
-- Name: shipping_companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shipping_companies_id_seq', 1, true);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 21, true);


--
-- Name: replit_database_migrations_v1 replit_database_migrations_v1_pkey; Type: CONSTRAINT; Schema: _system; Owner: -
--

ALTER TABLE ONLY _system.replit_database_migrations_v1
    ADD CONSTRAINT replit_database_migrations_v1_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements inventory_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_pkey PRIMARY KEY (id);


--
-- Name: payment_allocations payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_pkey PRIMARY KEY (id);


--
-- Name: product_types product_types_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_types
    ADD CONSTRAINT product_types_name_unique UNIQUE (name);


--
-- Name: product_types product_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_types
    ADD CONSTRAINT product_types_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: shipment_customs_details shipment_customs_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_customs_details
    ADD CONSTRAINT shipment_customs_details_pkey PRIMARY KEY (id);


--
-- Name: shipment_customs_details shipment_customs_details_shipment_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_customs_details
    ADD CONSTRAINT shipment_customs_details_shipment_id_unique UNIQUE (shipment_id);


--
-- Name: shipment_items shipment_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_items
    ADD CONSTRAINT shipment_items_pkey PRIMARY KEY (id);


--
-- Name: shipment_payments shipment_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_payments
    ADD CONSTRAINT shipment_payments_pkey PRIMARY KEY (id);


--
-- Name: shipment_shipping_details shipment_shipping_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_shipping_details
    ADD CONSTRAINT shipment_shipping_details_pkey PRIMARY KEY (id);


--
-- Name: shipment_shipping_details shipment_shipping_details_shipment_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_shipping_details
    ADD CONSTRAINT shipment_shipping_details_shipment_id_unique UNIQUE (shipment_id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_shipment_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_shipment_code_unique UNIQUE (shipment_code);


--
-- Name: shipping_companies shipping_companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_companies
    ADD CONSTRAINT shipping_companies_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: idx_replit_database_migrations_v1_build_id; Type: INDEX; Schema: _system; Owner: -
--

CREATE UNIQUE INDEX idx_replit_database_migrations_v1_build_id ON _system.replit_database_migrations_v1 USING btree (build_id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: backup_jobs backup_jobs_created_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_created_by_user_id_users_id_fk FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: inventory_movements inventory_movements_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_movements inventory_movements_shipment_id_shipments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_shipment_id_shipments_id_fk FOREIGN KEY (shipment_id) REFERENCES public.shipments(id);


--
-- Name: inventory_movements inventory_movements_shipment_item_id_shipment_items_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_shipment_item_id_shipment_items_id_fk FOREIGN KEY (shipment_item_id) REFERENCES public.shipment_items(id);


--
-- Name: payment_allocations payment_allocations_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: payment_allocations payment_allocations_payment_id_shipment_payments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_payment_id_shipment_payments_id_fk FOREIGN KEY (payment_id) REFERENCES public.shipment_payments(id);


--
-- Name: payment_allocations payment_allocations_shipment_id_shipments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_shipment_id_shipments_id_fk FOREIGN KEY (shipment_id) REFERENCES public.shipments(id);


--
-- Name: payment_allocations payment_allocations_supplier_id_suppliers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_supplier_id_suppliers_id_fk FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: products products_default_supplier_id_suppliers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_default_supplier_id_suppliers_id_fk FOREIGN KEY (default_supplier_id) REFERENCES public.suppliers(id);


--
-- Name: shipment_customs_details shipment_customs_details_shipment_id_shipments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_customs_details
    ADD CONSTRAINT shipment_customs_details_shipment_id_shipments_id_fk FOREIGN KEY (shipment_id) REFERENCES public.shipments(id);


--
-- Name: shipment_items shipment_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_items
    ADD CONSTRAINT shipment_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: shipment_items shipment_items_product_type_id_product_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_items
    ADD CONSTRAINT shipment_items_product_type_id_product_types_id_fk FOREIGN KEY (product_type_id) REFERENCES public.product_types(id);


--
-- Name: shipment_items shipment_items_shipment_id_shipments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_items
    ADD CONSTRAINT shipment_items_shipment_id_shipments_id_fk FOREIGN KEY (shipment_id) REFERENCES public.shipments(id);


--
-- Name: shipment_items shipment_items_supplier_id_suppliers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_items
    ADD CONSTRAINT shipment_items_supplier_id_suppliers_id_fk FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: shipment_payments shipment_payments_created_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_payments
    ADD CONSTRAINT shipment_payments_created_by_user_id_users_id_fk FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: shipment_payments shipment_payments_shipment_id_shipments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_payments
    ADD CONSTRAINT shipment_payments_shipment_id_shipments_id_fk FOREIGN KEY (shipment_id) REFERENCES public.shipments(id);


--
-- Name: shipment_shipping_details shipment_shipping_details_shipment_id_shipments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_shipping_details
    ADD CONSTRAINT shipment_shipping_details_shipment_id_shipments_id_fk FOREIGN KEY (shipment_id) REFERENCES public.shipments(id);


--
-- Name: shipments shipments_created_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_created_by_user_id_users_id_fk FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: shipments shipments_shipping_company_id_shipping_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_shipping_company_id_shipping_companies_id_fk FOREIGN KEY (shipping_company_id) REFERENCES public.shipping_companies(id);


--
-- PostgreSQL database dump complete
--

